import { Component, OnInit,ViewChild } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { AnalysisService } from '../shared/analysis.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { HistoryService } from 'src/app/shared/history.service';
import { CreateModalComponent } from '../create-modal/create-modal.component';

@Component({
  selector: 'app-dash-info',
  templateUrl: './dash-info.component.html',
  styleUrls: ['./dash-info.component.css']
})
export class DashInfoComponent implements OnInit {
type : string;
listData: MatTableDataSource<any>;
displayedColumns: string[] = ['Name', 'Address', 'contact', 'TimeSlot','service','date','status','actions'];
@ViewChild(MatSort) sort: MatSort;
tableData = [];
user: FirebaseUserModel = new FirebaseUserModel();
@ViewChild(MatPaginator) paginator: MatPaginator;
searchKey: string;

  constructor(private route: ActivatedRoute, private service : AnalysisService,
     private historyService: HistoryService ,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })
  this.route.params.subscribe(query =>{
  this.type = query['type']
})
this.populateData(this.type);
  }
  populateData(type){

    this.callFunction(type).subscribe(
      res => {
        let  list = res;
        // res.map(a =>
        //   // this.tableData.push(a)
        //   let list = a;
        // )
        console.log(this.tableData)
        this.listData = new MatTableDataSource(list);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
        this.listData.filterPredicate = (data, filter) => {
          return this.displayedColumns.some(ele => {
            return ele != 'actions' && data[ele].toLowerCase().indexOf(filter) != -1;
          });
        }
      })

  }


  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }

  callFunction(type){
    if(type =='upcoming'){
    return this.service.getUpcomingAppointment(this.user.uid)
    }
    else if (type =='accepted'){
     return this.service.getAcceptedAppointment(this.user.uid)
    }
    else{
      return this.service.getPendingAppointment(this.user.uid)
    }
    }

    changeStatus(element){
      let obj ={
        id : element.id,
        status : "accepted",
        comments : ""
      }
      let isSent =true;
     // element.status = "accepted";
      this.historyService.updateStatus(this.user.uid,obj).then(function () {
        console.log("Status updated--accpeted");
        isSent =true;
       
      })
      .catch(function (error) {
        isSent = false;
        console.error("Something gone wrong!", error);
        alert("Something went wrong !")
       
      });
    }
    changeStatusRejected(element){
      // element.status = "rejected";
      console.log(element)
      this.historyService.typeModal.next('confirmModal')
      const dialogConfig = new MatDialogConfig();
      // dialogConfig.autoFocus= true;
      dialogConfig.width = "60%";
      dialogConfig.data = {
        uid: this.user.uid,
        status : element.status,
        id : element.id
      }
      // // dialogConfig.disableClose = true
      this.dialog.open(CreateModalComponent, dialogConfig);
      
    
    }
    onCreate(){
      // this.service.typeModal.next('create')
      // const dialogConfig = new MatDialogConfig();
      // // dialogConfig.autoFocus= true;
      // dialogConfig.width = "60%";
      // dialogConfig.data = {
      //   uid: this.user.uid
      // }
      // // dialogConfig.disableClose = true
      // this.dialog.open(CreateModalComponent, dialogConfig);
    }
    onSearchClear() {
      this.searchKey = "";
      this.applyFilter();
    }

}
