import { Component, OnInit, ViewChild } from '@angular/core';
import { HistoryService } from 'src/app/shared/history.service';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model';
import { DataService } from '../shared/data.service';
import 'datatables.net';
import * as $ from 'jquery';
import * as moment from 'moment';
import {CheckBoxComponent}  from '../check-box/check-box.component'
import { FormService } from '../shared/form.service';
import {FormBuilder, FormGroup, Validators,FormArray,FormControl} from '@angular/forms';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import { element } from 'protractor';
import { BusinessFormComponent } from '../business-form/business-form.component';
// declare var $;
@Component({
  selector: 'app-data-tables-appointment',
  templateUrl: './data-tables-appointment.component.html',
  styleUrls: ['./data-tables-appointment.component.css'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: {displayDefaultIndicatorType: false}
  }]
})
export class DataTablesAppointmentComponent implements OnInit {
  user: FirebaseUserModel = new FirebaseUserModel();
  @ViewChild(CheckBoxComponent) child :CheckBoxComponent;
  @ViewChild(BusinessFormComponent) childBusiness :BusinessFormComponent;
  firstFormGroup: FormGroup;
  serviceForm: FormGroup;
  workingForm : FormGroup;
  formValue : boolean;
  dataTable: any;
  dtOptions: any;
  tableData = [];
  childFormValidCheck : any;
  
 serviceArray: any =[]
  patterns="(ABC\,|A\.B\.C\,|A\.B\,)"
  WeekDays = [
    { id: 'Monday', completed : false, name: 'Monday' }, 
    { id: 'Tuesday', completed : false, name: 'Tuesday' },
    { id: 'Wednesday', completed : false, name: 'Wednesday' },
    { id: 'Thrusday', completed : false, name: 'Thrusday' },
    { id: 'Friday', completed : false, name: 'Friday' },
    { id: 'Saturday', completed : false, name: 'Saturday' },
    { id: 'Sunday', completed : false, name: 'Sunday' }
    ];

days : any =['Monday', 'Tuesday','Wednesday']
  isLinear = true;
  isCompleted :boolean =false;
  public servicess: FormArray;
  // public WorkingDays : FormArray;
  date :any =moment('2015-11-18T00:00Z');
  options = {
    format: "HH:mm a",
    icons: {
    up: 'fa fa-arrow-up',
    down: 'fa fa-arrow-down'},
    buttons :{showClose: false} 
    
    // ...
};
  btype: string[] = ['IT',
     'Barber',
     'Medical',
     'HealthCare'
  ];
  @ViewChild('dataTable', {static: true}) table;
  constructor(private service : HistoryService,private dataService : DataService,private route: ActivatedRoute,private _formBuilder: FormBuilder,
    private formService :FormService) { }

  ngOnInit(): void {
    this.formValue =true;
  }
  Done(){
    if (this.child.serviceForm.invalid && this.childBusiness.businessFormGroup.invalid){
      alert("Some information is missing ! Try again ")
    }else{
      this.child.logMyValue();
      this.childBusiness.logBusinessValue();
      
    }
 
  }

  toggle(){
    this.formValue = !this.formValue;
}

toggleNext(){
  if(this.childBusiness.businessFormGroup.invalid){
    alert("Fill in the correct Details!")
  }else{
    this.formValue = !this.formValue
  }
}

}

