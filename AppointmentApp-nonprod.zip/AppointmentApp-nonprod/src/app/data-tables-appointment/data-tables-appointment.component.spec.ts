import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataTablesAppointmentComponent } from './data-tables-appointment.component';

describe('DataTablesAppointmentComponent', () => {
  let component: DataTablesAppointmentComponent;
  let fixture: ComponentFixture<DataTablesAppointmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataTablesAppointmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTablesAppointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
