import { Injectable } from "@angular/core";
import { AngularFirestore } from "@angular/fire/firestore";
import { Details } from "../Model/Details";
import { ServiceDetails } from "../Model/ServiceDetails";
import { Appointment } from '../Model/appointment';
import { async } from '@angular/core/testing';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
// import { map } from 'rxjs';

@Injectable({
  providedIn: "root",
})
export class FormService {
  // businessId: string
  formValue = true;
  isSent = true;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  constructor(private firestore: AngularFirestore, private _snackBar: MatSnackBar) {}


  openSnackBar(message) {
    this._snackBar.open(message, 'Try again', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
  insertAppointment(app : Appointment, businessId){
    var businessDocument = this.firestore
    .collection("Business")
    .doc(businessId);

    return businessDocument
    .collection("Appointments")
    .add(JSON.parse(JSON.stringify(app)))
    
  }

  insertBusinessDetails(details: Details,businessId) {
//this.businessId = firebase.auth.Currentuser.uid;
console.log(businessId)
    var businessDocument = this.firestore
      .collection("Business")
      .doc(businessId);

    // console.log(JSON.parse(JSON.stringify(serviceDetails)));
    // businessDocument
    //   .collection("Services")
    //   .add(JSON.parse(JSON.stringify(serviceDetails)))
    //   .then(function () {
    //     console.log("Services Document Added");
    //   })
    //   .catch(function (error) {
    //     console.error("Error adding document:", error);
    //   });
    //   businessDocument.collection('Appointment');

    businessDocument
      .collection("Details")
      .add(JSON.parse(JSON.stringify(details)))
      .then(function () {
        console.log(" Details Document Added");
      })
      .catch(function (error) {
        console.error("Error adding document:", error);
      });
   }

   getBusinessDetails(businessId){
    var businessDocument = this.firestore
    .collection("Business");

   return this.firestore.collection("Business").doc(businessId).collection("Details").valueChanges({ idField: 'docId' });
 
   }

   getServiceDetails(businessId){
    var businessDocument = this.firestore
    .collection("Business");

   return this.firestore.collection("Business").doc(businessId).collection("Services").valueChanges();
 
   }

   updateBusinessDetails(businessId, details: Details, docID : string){
// console.log(docID)
    var businessDocument = this.firestore
    .collection("Business")
    .doc(businessId);

   return businessDocument
    .collection("Details")
    .doc(docID)
    .set({
       address: details.address,
       contact : details.contact,
       city: details.city,
      state: details.state

     }, { merge: true });
    }


    insertServiceDetails(businessId ,serviceDetails ){
      var businessDocument = this.firestore
      .collection("Business")
      .doc(businessId);
      console.log(JSON.parse(JSON.stringify(serviceDetails)));
      serviceDetails.map( obj =>{
        businessDocument
        .collection("Services")
        .add(JSON.parse(JSON.stringify(obj)))
        .then(function () {
          this.isSent = true;
          console.log("Services Document Added");
        })
        .catch(function (error) {
          this.isSent = false;
          console.error("Error adding document:", error);
          this.openSnackBar('Error Adding your Services !');
        });

      })
      return this.isSent;
    }

}
