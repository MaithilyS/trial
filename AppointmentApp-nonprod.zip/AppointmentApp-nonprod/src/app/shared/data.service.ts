import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private messageSource = new BehaviorSubject('Error');
  userDataSource: BehaviorSubject<Array<any>> = new BehaviorSubject([]);
  currentMessage = this.messageSource.asObservable();

  constructor() { }

  changeMessage(message: string) {
    this.messageSource.next(message)
  }

  addData(dataObj) {
    const currentValue = this.userDataSource.value;
    const updatedValue = [...currentValue, dataObj];
    this.userDataSource.next(updatedValue);
}

// giveData (){
//   this.userDataSource.pipe( tap (
//   obj =>{
//       obj.WeekDays= obj.WeekDays.filter(
//         t=> {
//           return t.completed ? t : null
//         }
//       )
//       return {
//       name :  obj.serviceName,
//        week : obj.WeekDays
//       }
//     }))
//   }
 
  // )
}


