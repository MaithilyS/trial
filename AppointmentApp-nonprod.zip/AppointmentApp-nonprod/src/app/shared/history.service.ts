import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { firestore } from 'firebase';
import { DatePipe } from '@angular/common';
import { tap, map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';

export interface ClientHistoryItem {
  id?: string
  Name :string;
  Address:string;
  TimeSlot : string;
  contact:string;
  date :firestore.Timestamp;
  status?: string
}


@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  todayDate :string;
  public typeModal: BehaviorSubject<string> = new BehaviorSubject<string>('null');
  constructor(private firestore: AngularFirestore, private datePipe: DatePipe) { }

  getAppointment(businesssId) { 
    return  this.firestore.collection("Business").doc(businesssId).collection<ClientHistoryItem>("Appointments").valueChanges();
  }
  getTodayAppointment(businesssId) { 
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return  this.firestore.collection("Business").doc(businesssId).collection<ClientHistoryItem>("Appointments",ref => ref.where('date', '==', this.todayDate)).valueChanges();
  }

  getDataTableAppointment(businesssId){
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return this.firestore.collection("Business").doc(businesssId).collection("Appointments",ref => ref.where('date', '==', this.todayDate)).snapshotChanges().pipe(
      map(
        res => res.map(
          a => {
            const data = a.payload.doc.data() as ClientHistoryItem;
              data.id = a.payload.doc.id;
             return data;
          }
        )
      
    ));
  }

  updateStatus(businesssId,data){
    if(data.status=="accepted"){
      return this.firestore.collection("Business").doc(businesssId).collection("Appointments")
      .doc(data.id)
      .set({ status: data.status }, { merge: true });
    }else{
      return this.firestore.collection("Business").doc(businesssId).collection("Appointments")
      .doc(data.id)
      .set({ status: data.status, comments:data.comments }, { merge: true });
    }

  }

  listenupdates(businesssId){
    return this.firestore.collection("Business").doc(businesssId).collection("Appointments");
  }
}
