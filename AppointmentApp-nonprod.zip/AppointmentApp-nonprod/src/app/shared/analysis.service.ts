import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { firestore } from 'firebase';
import { DatePipe } from '@angular/common';
import { tap, map } from 'rxjs/operators';
import { ClientHistoryItem } from './history.service';

@Injectable({
  providedIn: 'root'
})
export class AnalysisService {
  todayDate :string;
  constructor(private firestore: AngularFirestore,private datePipe: DatePipe) { }

  getAcceptedAppointment(businesssId){
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return this.firestore.collection("Business").doc(businesssId).collection("Appointments",ref => ref.where('date', '==', this.todayDate).where('status', '==', 'accepted') ).snapshotChanges().pipe(
      map(
        res => res.map(
          a => {
            const data = a.payload.doc.data() as ClientHistoryItem;
              data.id = a.payload.doc.id;
             return data;
          }
        )
      
    ));
  }
  getPendingAppointment(businesssId){
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return this.firestore.collection("Business").doc(businesssId).collection("Appointments",ref => ref.where('date', '==', this.todayDate).where('status', '==', 'pending') ).snapshotChanges().pipe(
      map(
        res => res.map(
          a => {
            const data = a.payload.doc.data() as ClientHistoryItem;
              data.id = a.payload.doc.id;
             return data;
          }
        )
      
    ));
  }

  getUpcomingAppointment(businesssId){
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return this.firestore.collection("Business").doc(businesssId).collection("Appointments",ref => ref.where('date', '>',this.todayDate)).snapshotChanges().pipe(
      map(
        res => res.map(
          a => {
            const data = a.payload.doc.data() as ClientHistoryItem;
              data.id = a.payload.doc.id;
             return data;
          }
        )
      
    ));
  }
}
