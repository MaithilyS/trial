import { Component, OnInit, Output ,EventEmitter ,Input } from '@angular/core';
import {FormBuilder, FormGroup, Validators,FormArray,FormControl} from '@angular/forms';
import { FormService } from '../shared/form.service';
import { Details } from '../Model/Details';
  

@Component({
  selector: 'app-business-form',
  templateUrl: './business-form.component.html',
  styleUrls: ['./business-form.component.css']
})
export class BusinessFormComponent implements OnInit {
  btype: string[] = ['IT',
  'Barber',
  'Medical',
  'HealthCare'
];
businessFormGroup :FormGroup;
@Input() businessId : any 
detail : Details
  constructor( private _formBuilder: FormBuilder, private service :FormService) { }

  ngOnInit(): void {
    this.businessFormGroup = this._formBuilder.group({
      businessName: ['', Validators.required],
      businessType : ['', Validators.required],
      addressControl : ['', Validators.required],
      contactControl: ['', Validators.required],
      cityControl: ['', Validators.required],
      stateControl: ['', Validators.required],
      gstcontrol : ['',Validators.required]
    });
  }

  logBusinessValue(){
console.log(this.businessFormGroup.value)
this.detail = new Details();
this.detail.businessName = this.businessFormGroup.value.businessName;
this.detail.businessType = this.businessFormGroup.value.businessType;

this.detail.contact = this.businessFormGroup.value.contactControl;

this.detail.address = this.businessFormGroup.value.addressControl;
this.detail.state = this.businessFormGroup.value.stateControl;
this.detail.city = this.businessFormGroup.value.cityControl;
this.detail.gst = this.businessFormGroup.value.gstcontrol;

console.log(this.detail)
this.service.insertBusinessDetails(this.detail,this.businessId)

  }

toggle(){
this.service.formValue =!this.service.formValue;
}



}
