import { Injectable } from "@angular/core";
// import 'rxjs/add/operator/toPromise';
// import { AngularFireAuth } from '@angular/fire/auth';
// import * as firebase from 'firebase/app';
import { Router, Params } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/auth';
import { firebase } from '@firebase/app';
import '@firebase/auth';
import { PasswordFormComponent } from '../password-form/password-form.component';

@Injectable()
export class AuthService {
   passwordComp : PasswordFormComponent;
  constructor(
   public afAuth: AngularFireAuth,private router : Router
 ){}


  doGoogleLogin(){
    return new Promise<any>((resolve, reject) => {
      let provider = new firebase.auth.GoogleAuthProvider();
      provider.addScope('profile');
      provider.addScope('email');
      this.afAuth.
      signInWithPopup(provider)
      .then(res => {
        resolve(res);
      }, err => {
        console.log(err);
        reject(err);
      })
    })
  }

  doRegister(value){
    console.log(firebase.auth)
    return new Promise<any>((resolve, reject) => {
      firebase.auth().createUserWithEmailAndPassword(value.email, value.password)
      .then(res => {
        resolve(res);
      }, err => reject(err))
    })
  }

  doLogin(value){
    return new Promise<any>((resolve, reject) => {
      firebase.auth().signInWithEmailAndPassword(value.email, value.password)
      .then(res => {
        resolve(res);
      }, err => reject(err))
    })
  }

  doLogout(){
    return new Promise((resolve, reject) => {
      if(firebase.auth().currentUser){
        this.afAuth.signOut();
        // this.authenticated = false;
        resolve();
      }
      else{
        reject();
      }
    });
  }

  resetPassword(email){
    this.afAuth.sendPasswordResetEmail(email) 
  .then(
    () => alert('A password reset link has been sent to your email address'), 
    (rejectionReason) => alert(rejectionReason)) 
  .catch(e => alert('An error occurred while attempting to reset your password')); 
  }

  PasswordResetCode(actionCode){
   
    this.afAuth
    .verifyPasswordResetCode(actionCode)
    .then(email => {
      this.passwordComp.actionCodeChecked = true;
    }).catch(e => {
      // Invalid or expired action code. Ask user to try to
      // reset the password again.
      alert(e);
      this.router.navigate(['login']);
    });
  }

  confirmPassowrd(actionCode,newPassword){
    this.afAuth.confirmPasswordReset(
      actionCode,   
      newPassword
  )
  .then(resp => {
    // Password reset has been confirmed and new password updated.
    alert('New password has been saved');
    this.router.navigate(['/login']);
  }).catch(e => {
    // Error occurred during confirmation. The code might have
    // expired or the password is too weak.
    alert(e);
  });
}
  SignOut() {
    return this.afAuth.signOut().then(() => {
      this.router.navigate(['login']);
    })
  }



}
