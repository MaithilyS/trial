import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmployeeService } from '../shared/employee.service';
import { FormGroup, FormControl, Validators,FormBuilder } from "@angular/forms";
import { Appointment } from '../Model/appointment';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from '../core/user.model';
import { FormService } from '../shared/form.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import {MAT_DIALOG_DATA, MatDialog, MatDialogRef} from '@angular/material/dialog';
import { Inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';
import { HistoryService } from 'src/app/shared/history.service';
import { AppointmentComponent } from '../appointment/appointment.component';

@Component({
  selector: 'app-create-modal',
  templateUrl: './create-modal.component.html',
  styleUrls: ['./create-modal.component.css']
})

export class CreateModalComponent implements OnInit,OnDestroy {
  form: FormGroup ;
  appModel : Appointment;
  type : any;
  typeSub : Subscription;
  appointmentForm : FormGroup
   timeStops = new Array();
   serviceObjectArray =[]
  user: FirebaseUserModel = new FirebaseUserModel();

  constructor(public service : FormService,private route: ActivatedRoute,private Historyservice: HistoryService,
     public snackBar: MatSnackBar,@Inject(MAT_DIALOG_DATA) public data: any, 
     private datePipe: DatePipe, private _formBuilder : FormBuilder,
     private dialogRef:MatDialogRef<CreateModalComponent>) { }

  ngOnInit(): void {
    console.log(this.data)

  // this.calculateTimeSlot("08:00","17:00",15)
this.typeSub = this.Historyservice.typeModal.subscribe(
  value =>  this.type =value
);
this.user.uid =this.data.uid;
this.getDataService();
this.appointmentForm = this._formBuilder.group({
  name: ['', Validators.required],
  contact : ['', Validators.required],
  address : ['',Validators.required],
  service : ['', Validators.required],
  timeSlot: ['', Validators.required],
  date: ['', Validators.required]
});
  }

 getDataService(){
   this.service.getServiceDetails(this.user.uid).subscribe(res => this.serviceObjectArray = res);
 }
 closeDialog(){
  this.dialogRef.close();
}

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
       duration: 3000,
    });
  }

changeStatus(value){
console.log(value)
let obj ={
  id : this.data.id,
  status : "rejected",
  comments: value
}
let isSent =true;
this.Historyservice.updateStatus(this.data.uid,obj).then(function () {
  console.log("Status updated !");
  isSent =true;
})
.catch(function (error) {
  isSent = false;
  console.error("Something gone wrong!", error);
  alert("Something went wrong !")
 
});

if(isSent)
this.dialogRef.close();
  }
 
onChange(obj)
{
  let index, serviceName;
[index,serviceName]=obj.split(":")
console.log(this.serviceObjectArray[index])
this.calculateTimeSlot(this.serviceObjectArray[index].startTime,
  this.serviceObjectArray[index].endTime,this.serviceObjectArray[index].TimeDivision)
}


 calculateTimeSlot(startTime , EndTime,slots){
  //  let h,m,hours,min
  //  [h,m] =startTime.split(":");
  //  [hours,min] =EndTime.split(":");
  // var startTimes = moment().utc().set({hour:h,minute:m});
  // var endTime = moment().utc().set({hour:hours,minute:min});
  this.timeStops.length =0;
  var startTimes = moment(startTime, 'HH:mm');
  var endTime = moment(EndTime, 'HH:mm');
  
console.log(startTimes)
console.log(endTime)
console.log(slots)
  
  while(startTimes <= endTime){
    //console.log(startTimes)
      this.timeStops.push(moment(startTimes).format('HH:mm'));
      startTimes.add(parseInt(slots,10),'minutes');
  }
  
  console.log('timeStops ', this.timeStops)
 }


 getNextElement(i){
if(i+1 == this.timeStops.length){
  return this.timeStops[i] + " to "+ this.timeStops[i]
}else{
  return this.timeStops[i] + " to "+ this.timeStops[i+1]
}
 }

 logValue(){
   console.log(this.appointmentForm.value)
   this.appModel = new Appointment();
   this.appModel.Name =this.appointmentForm.value.name;
   this.appModel.Address =this.appointmentForm.value.address;
   this.appModel.status ="accepted";
   this.appModel.TimeSlot =this.appointmentForm.value.timeSlot;
   this.appModel.date =this.datePipe.transform(this.appointmentForm.get('date').value, 'yyyy-MM-dd');
   this.appModel.contact =this.appointmentForm.value.contact;
   this.appModel.service =this.appointmentForm.value.service;
   this.insertAppointment(this.appModel)
   this.appointmentForm.reset();
   console.log(this.appModel)
 }

 insertAppointment(appModel){
   let isSent = true;
  this.service.insertAppointment(appModel,this.user.uid).then(function () {
    console.log("Appointment Added");
    isSent =true;
   
  })
  .catch(function (error) {
    isSent = false;
    console.error("Something gone wrong!", error);
   
  });

  if(isSent){
    this.openSnackBar("Appointment Booked!" , "done!")
  }
  else{
    this.openSnackBar("Something gone wrong!" , "Try Again")
  }
 
 }
 ngOnDestroy(){
  this.typeSub.unsubscribe();
 }
}


