export class ServiceDetails{
    ServiceName : string;
    startTime : string;
    endTime : string;
    TimeDivision : string;
    Days : Array<any> 
} 