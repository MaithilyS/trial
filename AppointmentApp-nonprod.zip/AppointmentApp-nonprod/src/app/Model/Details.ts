export class Details{
    businessName: string;
    businessType : string;
    address: string;
    contact:string;
    city: string;
    state: string;
    gst : string;
    docId? : string;
}