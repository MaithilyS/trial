import { Component, OnInit,ViewChild } from '@angular/core';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import {CheckBoxComponent}  from '../check-box/check-box.component';
import { BusinessFormComponent } from '../business-form/business-form.component';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model'
@Component({
  selector: 'app-fill-form',
  templateUrl: './fill-form.component.html',
  styleUrls: ['./fill-form.component.css'],
  providers: [{
  provide: STEPPER_GLOBAL_OPTIONS, useValue: {displayDefaultIndicatorType: false}
  }]
})
export class FillFormComponent implements OnInit {
  @ViewChild(CheckBoxComponent) child :CheckBoxComponent;
  @ViewChild(BusinessFormComponent) childBusiness :BusinessFormComponent;
  user: FirebaseUserModel = new FirebaseUserModel();
  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })
    
  }

  getFormData(){
    if (this.child.serviceForm.invalid || this.childBusiness.businessFormGroup.invalid){
      alert("Some information is missing ! Try again ")
    }else{
      this.child.logMyValue();
      this.childBusiness.logBusinessValue();
      
   }
  }
}
