import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// import { ClientHistoryComponent } from './client-history/client-history.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthService } from './core/auth.service';
import { FormService } from './shared/form.service';
import { UserComponent } from './user/user.component';
import { UserService } from './core/user.service';
import { AngularFireModule } from "@angular/fire";
import { AngularFirestoreModule } from "@angular/fire/firestore";
 import { BusinessFormComponent } from './business-form/business-form.component';
import { environment } from 'src/environments/environment';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { HistoryComponent } from './history/history.component';
import {EmployeeListComponent} from './employees/employee-list/employee-list.component';
import { UserResolver } from './user/user.resolver';
import { AuthGuard } from './core/auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReactiveFormsModule } from '@angular/forms';
import {AngularFireAuthModule} from '@angular/fire/auth';
import { FormsModule } from '@angular/forms';
import {MatNativeDateModule} from '@angular/material/core';
import { MaterialModule } from './material/material.module';
import { MainNavComponent } from './main-nav/main-nav.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { CreateModalComponent } from './create-modal/create-modal.component';
import { EmployeeService } from './shared/employee.service';
import { DatePipe } from '@angular/common';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatSnackBarModule } from '@angular/material/snack-bar';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { PasswordFormComponent } from './password-form/password-form.component';
import { SettingsComponent } from './settings/settings.component';
import { DataTablesAppointmentComponent } from './data-tables-appointment/data-tables-appointment.component';
import { DashComponent } from './dash/dash.component';
import { ServiceComponent } from './service/service.component';
import { NgTempusdominusBootstrapModule } from 'ngx-tempusdominus-bootstrap';
import { CheckBoxComponent } from './check-box/check-box.component';
import { ServiceOnboardingComponent } from './service-onboarding/service-onboarding.component';
import { DashInfoComponent } from './dash-info/dash-info.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FillFormComponent } from './fill-form/fill-form.component';
@NgModule({
  declarations: [
    AppComponent,
   BusinessFormComponent,
    DashboardComponent,
    // HistoryComponent,
    LoginComponent,
    UserComponent,
    RegisterComponent,
    // ClientHistoryComponent,
    EmployeeListComponent,
    MainNavComponent,
    AppointmentComponent,
    CreateModalComponent,
    ResetPasswordComponent,
    PasswordFormComponent,
    SettingsComponent,
    DataTablesAppointmentComponent,
    DashComponent,
    ServiceComponent,
    CheckBoxComponent,
    ServiceOnboardingComponent,
    DashInfoComponent,
    FillFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AngularFirestoreModule,
    NgMultiSelectDropDownModule.forRoot(),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    BrowserAnimationsModule ,
    NgTempusdominusBootstrapModule,
    MatSnackBarModule ,
    MaterialModule,
    MatNativeDateModule,
    FormsModule,
    MatExpansionModule
  ],
  providers: [FormService,AuthService,UserService ,UserResolver, AuthGuard, EmployeeService,DatePipe],
  bootstrap: [AppComponent],
  entryComponents:[CreateModalComponent]
})
export class AppModule { }
