import { Component, OnInit,ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
// import { HistoryComponent } from 'src/app/history/history.component';
import { HistoryService } from 'src/app/shared/history.service';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model'
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';

@Component({ 
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private route: ActivatedRoute,private service: HistoryService) { } 

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['Name', 'Address', 'contact','TimeSlot'];
  @ViewChild(MatSort) sort: MatSort;
  array : any[];
  user: FirebaseUserModel = new FirebaseUserModel();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  searchKey: string;
  
  ngOnInit() {
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })
    this.service.getAppointment(this.user.uid).subscribe(
      list => {
        let array1 = list.map(item => {
          return{
            Name : item.Name,
            Address: item.Address,
            contact : item.contact,
            TimeSlot : item.TimeSlot
          }
        });
        this.listData = new MatTableDataSource(array1);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
        this.listData.filterPredicate = (data, filter) => {
          return this.displayedColumns.some(ele => {
            return ele != 'actions' && data[ele].toLowerCase().indexOf(filter) != -1;
          });
        };
        });
       
      }
      onSearchClear() {
        this.searchKey = "";
        this.applyFilter();
      }
    
      applyFilter() {
        this.listData.filter = this.searchKey.trim().toLowerCase();
      }
    
    }


