import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
// import { HistoryComponent } from 'src/app/history/history.component';
import { HistoryService } from 'src/app/shared/history.service';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model'
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { CreateModalComponent } from '../create-modal/create-modal.component';


@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {

  constructor(private route: ActivatedRoute, private service: HistoryService, private dialog: MatDialog) { }

 

  listData: MatTableDataSource<any>;
  displayedColumns: string[] = ['Name', 'Address', 'contact', 'TimeSlot','status','actions'];
  @ViewChild(MatSort) sort: MatSort;
  tableData = [];
  user: FirebaseUserModel = new FirebaseUserModel();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  searchKey: string;

  ngOnInit() {
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })
    this.service.getDataTableAppointment(this.user.uid).subscribe(
      res => {
        let  list = res;
        // res.map(a =>
        //   // this.tableData.push(a)
        //   let list = a;
        // )
        console.log(this.tableData)
        this.listData = new MatTableDataSource(list);
        this.listData.sort = this.sort;
        this.listData.paginator = this.paginator;
        this.listData.filterPredicate = (data, filter) => {
          return this.displayedColumns.some(ele => {
            return ele != 'actions' && data[ele].toLowerCase().indexOf(filter) != -1;
          });
        }
      })

  };
onSearchClear() {
  this.searchKey = "";
  this.applyFilter();
}

applyFilter() {
  this.listData.filter = this.searchKey.trim().toLowerCase();
}



changeStatus(element){
  element.status = "accepted";
  this.service.updateStatus(this.user.uid,element)
}
changeStatusRejected(element){
  element.status = "rejected";
  this.service.typeModal.next('confirmModal')
  const dialogConfig = new MatDialogConfig();
  // dialogConfig.autoFocus= true;
  dialogConfig.width = "60%";
  dialogConfig.data = {
    uid: this.user.uid
  }
  // dialogConfig.disableClose = true
  this.dialog.open(CreateModalComponent, dialogConfig);
  

}
onCreate(){
  this.service.typeModal.next('create')
  const dialogConfig = new MatDialogConfig();
  // dialogConfig.autoFocus= true;
  dialogConfig.width = "60%";
  dialogConfig.data = {
    uid: this.user.uid
  }
  // dialogConfig.disableClose = true
  this.dialog.open(CreateModalComponent, dialogConfig);
}
}

