import { Component, OnInit } from '@angular/core';
import { AuthService } from '../core/auth.service'

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
 
  constructor(public authService: AuthService) { }

  ngOnInit(): void {
  }

  resetPassword(email: String){
    if (!email) { 
      alert('Type in your email first'); 
    }else{
      this.authService.resetPassword(email)
      console.log(email)
    }
   
  }
}
