import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceOnboardingComponent } from './service-onboarding.component';

describe('ServiceOnboardingComponent', () => {
  let component: ServiceOnboardingComponent;
  let fixture: ComponentFixture<ServiceOnboardingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceOnboardingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceOnboardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
