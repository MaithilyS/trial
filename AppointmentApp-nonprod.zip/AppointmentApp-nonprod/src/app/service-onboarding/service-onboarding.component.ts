import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-onboarding',
  templateUrl: './service-onboarding.component.html',
  styleUrls: ['./service-onboarding.component.css']
})
export class ServiceOnboardingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
