import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { AuthService } from '../core/auth.service';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model'
import { FormService } from '../shared/form.service';
import { Details } from '../Model/Details';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

export interface DetailsID {
  businessName: string;
  address: string;
  contact:string;
  city: string;
  state: string;
  docId? : string;
}

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit ,AfterViewInit {
  panelOpenState = false;
  // basicObj : any
  details : Details;
  detailObject : DetailsID;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  updateForm : FormGroup;
  passwordForm : FormGroup;
  user: FirebaseUserModel = new FirebaseUserModel();
  @ViewChild('email') searchInput: ElementRef;
  detail: Observable<DetailsID[]>

  constructor(public authService: AuthService, private route: ActivatedRoute, private service : FormService, private fb: FormBuilder,private _snackBar: MatSnackBar) {
    this.createForm();
   }

  ngOnInit(): void {

    this.details = new Details();
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })

   this.service.getBusinessDetails(this.user.uid).subscribe(res =>
   {
     console.log(res)
    // [this.basicObj] = res;
    res.map( basicObj =>{
  this.details.businessName = basicObj.businessName;
  this.details.address =basicObj.address;
  this.details.city =basicObj.city;
  this.details.state =basicObj.state;
  this.details.contact =basicObj.contact;
  this.details.docId =basicObj.docId;
    })
   
  
    this.setFormValues();
   })

   console.log(this.details)

    // console.log(this.detail)
 

  }

  ngAfterViewInit() {
  
  }

  openSnackBar(message) {
    this._snackBar.open(message, 'Done!', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
  sendMail(mail : string){
    if (!mail) { 
      alert('Type in your email first'); 
    }else{
      this.authService.resetPassword(mail);
      this.searchInput.nativeElement.value = '';
    
    }
   
  }
  createForm(){
    this.passwordForm = this.fb.group({
      'email': ['',Validators.required]
    })
    this.updateForm = this.fb.group({
      docId : [''],
      businessName: ['', Validators.required ],
      contact: ['', Validators.required ],
      state: ['',Validators.required],
      address: ['',Validators.required],
      city: ['',Validators.required]
    });
  
  }

  setFormValues(){
    this.updateForm.setValue({
      docId : this.details.docId,
      'businessName' : this.details.businessName,
      address: this.details.address,
        'contact' : this.details.contact,
        state : this.details.state,
        city : this.details.city   
  
  });
console.log(this.details)
// this.updateForm.controls['businessName'].setValue(this.details.businessName);
  // this.updateForm.get('updateForm.businessName').setValue(this.details.businessName);
  // this.updateForm.get('businessName').setValue({businessName :this.details.businessName})
  }
  updateDetailsInfo(value){
    console.log(value)
    this.service.updateBusinessDetails(this.user.uid,value,value.docId).then(
      res => {
        this.openSnackBar('Business Details Updated Successfully!');
        // this.router.navigate(['/dashboard']);
      }, err => {
        this.openSnackBar('Error Updating Business Details');
        console.log(err);
        // this.errorMessage = err.message;
      }
    )
   }

//   getDataFromObservable(){
//     this.detailObject= new Details();
// var x: any
//     for (x in this.detail) {
//       this.detailObject.businessName = x.businessName,
//       this.detailObject.address = x.address,
//       this.detailObject.city = x.city,
//       this.detailObject.state = x.state,
//       this.detailObject.contact = x.contact
//       console.log(this.detailObject)
//     }

//     return this.detailObject;
//   }
}
