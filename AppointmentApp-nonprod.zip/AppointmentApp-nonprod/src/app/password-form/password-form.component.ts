import { Component, OnInit } from '@angular/core';
import { AuthService } from '../core/auth.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-password-form',
  templateUrl: './password-form.component.html',
  styleUrls: ['./password-form.component.css']
})
export class PasswordFormComponent implements OnInit {
  ngUnsubscribe: Subject<any> = new Subject<any>();
  // actions = UserManagementActions;

  // The user management actoin to be completed
  mode: string;
  // Just a code Firebase uses to prove that
  // this is a real password reset.
  actionCode: string;
  passwordForm : FormGroup;
  // newPassword: string;
  // confirmPassword: string;
  errorMessage: string =""
  actionCodeChecked: boolean = false;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private fb: FormBuilder,

  ) { }

  ngOnInit() {
    this.activatedRoute.queryParams
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(params => {
        // if we didn't receive any parameters, 
        // we can't do anything
        if (!params) this.router.navigate(['/home']);

        this.mode = params['mode'];
        this.actionCode = params['oobCode'];

        switch (params['mode']) {
          case 'resetPassword': {
            // Verify the password reset code is valid.
            this.authService.afAuth.verifyPasswordResetCode(this.actionCode)
            .then(email => {
              this.actionCodeChecked = true;
            }).catch(e => {
              // Invalid or expired action code. Ask user to try to
              // reset the password again.
              alert(e);
              this.router.navigate(['login']);
            });

          } break
          case 'recoverEmail': {

          } break
          case 'verifyEmail': {

          } break
          default: {
            console.log('query parameters are missing');
            this.router.navigate(['login']);
          }
        }
      })

      this.createForm();
  }


  createForm(){
    this.passwordForm = this.fb.group({
      password: ['', Validators.required ],
      newPassword: ['',Validators.required]
    });
  }
  ngOnDestroy() {
    // End all subscriptions listening to ngUnsubscribe
    // to avoid memory leaks.
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  /**
   * Attempt to confirm the password reset with firebase and
   * navigate user back to home.
   */
  handleResetPassword() {
    if (this.passwordForm.get('password').value != this.passwordForm.get('newPassword').value) {
      alert('New Password and Confirm Password do not match');
      return;
    }
    // Save the new password.
    this.authService.confirmPassowrd(
        this.actionCode,   
        this.passwordForm.get('password').value
    );
    this.passwordForm.setValue({
      password :'',
      newPassword :''
});
  }

}
