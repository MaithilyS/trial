import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
// import { DataService } from '../shared/data.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-check-box',
  templateUrl: './check-box.component.html',
  styleUrls: ['./check-box.component.scss']
})
export class CheckBoxComponent implements OnInit {
  weekDays = [];
  selectedDays: any;
  // dropdownSettings: IDropdownSettings = {};

  dropdownList = [];
  selectedItems = [];
  dropdownSettings: IDropdownSettings = {};

  serviceForm: FormGroup;
  serviceArray: any = [];
  options = {
    format: 'HH:mm a',
    icons: {
      up: 'fa fa-arrow-up',
      down: 'fa fa-arrow-down'
    },
    buttons: { showClose: false }

    // ...
  };
  expanded = false;
  @ViewChild('selectWeekdays', { static: false }) selectWeekdays: ElementRef;
  public servicess: FormArray;

  constructor(public _formBuilder: FormBuilder) {
  }

  ngOnInit(): void {

    this.weekDays = [
      { item_id: 1, item_text: 'Sunday' },
      { item_id: 2, item_text: 'Monday' },
      { item_id: 3, item_text: 'Tuesday' },
      { item_id: 4, item_text: 'Wednesday' },
      { item_id: 5, item_text: 'Thursday' },
      { item_id: 6, item_text: 'Friday' },
      { item_id: 7, item_text: 'Saturday' },

    ];
    this.selectedDays = [
      { item_id: 1, item_text: 'Sunday' },
      { item_id: 2, item_text: 'Monday' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 7,
      allowSearchFilter: false
    };
    // this.weekDays = [
    //   { day: 'Sunday' },
    //   { day: 'Monday' },
    //   { day: 'Tuesday' },
    //   { day: 'Wednesday' },
    //   { day: 'Thursday' },
    //   { day: 'Friday' },
    //   { day: 'Saturday' }
    // ];

    // this.selectedDays = [
    //   { day: 'Sunday' }
    // ];

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };

    this.serviceForm = this._formBuilder.group({
      servicess: this._formBuilder.array([this.createService()]),

    });


  }

  createService(): FormGroup {
    return this._formBuilder.group({
      serviceName: ['', Validators.required],
      start_Time: ['', Validators.required],
      End_Time: ['', Validators.required],
      TimeSlotDivision: ['', Validators.required],
      DaysSlotDivision: ['', Validators.required]
    });
  }

  get serviceControls() {
    return this.serviceForm.get('servicess')['controls'];
  }

  getErrorControl(i, control) {
    const controlGroup = this.serviceForm.get('servicess')['controls'][i]
    return (!controlGroup.controls.control.valid && controlGroup.controls.control.touched);
    // return true;
  }

  addService(): void {
    this.servicess = this.serviceForm.get('servicess') as FormArray;
    this.servicess.push(this.createService());
  }

  removeService(i: number) {
    this.servicess.removeAt(i);
  }

  logValue(serviceForm) {
    // console.log(serviceForm.value)

    //   this.serviceArray.push(serviceForm.servicess.map(service =>  {
    //   return {
    //     serviceName : service.serviceName,
    //     startTime : service.start_Time.format("HH:MM"),
    //     endTime : service.End_Time.format("HH:MM"),
    //     TimeDivision : service.TimeSlotDivision
    //   }
    //  }))
    console.log('service form: ', serviceForm);
    (serviceForm.servicess.map(service => {
      this.serviceArray.push({
        serviceName: service.serviceName,
        startTime: service.start_Time,
        endTime: service.End_Time,
        TimeDivision: service.TimeSlotDivision,
        Days: service.DaysSlotDivision,
      })
    }))
    console.log(this.serviceArray)
  }

  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

  // showCheckboxes() {
  //   // console.log(this.expanded)
  //   // console.log('show check boxes');
  //   if (!this.expanded) {
  //     this.selectWeekdays.nativeElement.style.display = 'block';
  //     this.expanded = true;
  //   } else {
  //     this.selectWeekdays.nativeElement.style.display = "none";
  //     this.expanded = false;
  //   }
  // }

  // changeDayProperty(i: number) {
  //   this.weekdays[i].selected = !this.weekdays[i].selected;
  // }

  // getSelectedDays() {
  //   this.weekdays.forEach(day => {
  //     if(day.selected) {
  //       this.selectedDays.push(day.day);
  //     }
  //   })
  //   return this.selectedDays;
  // }


}
