import { Component, OnInit } from '@angular/core';
import { AnalysisService } from '../shared/analysis.service';
import { ActivatedRoute ,Router} from '@angular/router';
import { FirebaseUserModel } from 'src/app/core/user.model';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { HistoryService } from 'src/app/shared/history.service';
import { CreateModalComponent } from '../create-modal/create-modal.component';



@Component({
  selector: 'app-dash',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.css']
})
export class DashComponent implements OnInit {
dateToday = new Date().toDateString();
acceptedCount : number =0;
pendingCount : number =0;
upcomingCount : number =0;
user: FirebaseUserModel = new FirebaseUserModel();
  constructor(private service : AnalysisService,private route: ActivatedRoute, private router: Router,
    private historyService: HistoryService ,private dialog: MatDialog ) { }

  ngOnInit(): void {
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })

    this.service.getAcceptedAppointment(this.user.uid).subscribe(
      res=> this.acceptedCount = res.length
    )
    this.service.getUpcomingAppointment(this.user.uid).subscribe(
      res=> this.upcomingCount = res.length
    )
    this.service.getPendingAppointment(this.user.uid).subscribe(
      res=> this.pendingCount = res.length
    )

  }

  DashInfo(type : string){
    this.router.navigate(['/dashboard/dashInfo',type])
  }
  onCreate(){
    this.historyService.typeModal.next('create')
    const dialogConfig = new MatDialogConfig();
    // dialogConfig.autoFocus= true;
    dialogConfig.width = "60%";
    dialogConfig.data = {
      uid: this.user.uid
    }
    dialogConfig.disableClose = true
    this.dialog.open(CreateModalComponent, dialogConfig);
  }
}
