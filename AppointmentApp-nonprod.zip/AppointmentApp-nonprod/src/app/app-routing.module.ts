import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { HistoryComponent } from './history/history.component';
// import { BusinessFormComponent } from './onboarding/business-form/business-form.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { UserResolver } from './user/user.resolver';
import { AuthGuard } from './core/auth.guard';
// import { ClientHistoryComponent } from './client-history/client-history.component';
import { EmployeeListComponent } from './employees/employee-list/employee-list.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { PasswordFormComponent } from './password-form/password-form.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SettingsComponent } from './settings/settings.component';
import { DataTablesAppointmentComponent } from './data-tables-appointment/data-tables-appointment.component';
import { DashComponent } from './dash/dash.component';
import { DashInfoComponent } from './dash-info/dash-info.component';
import { FillFormComponent } from './fill-form/fill-form.component';

const routes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full' },
  {path: 'signup' , component:RegisterComponent, canActivate:[AuthGuard] },
  {path: 'login' , component:LoginComponent ,
  children:[
   
  ],
  canActivate:[AuthGuard] },
{path: 'business-form' , component:FillFormComponent, resolve: { data: UserResolver}},
  {
    path: 'dashboard' ,
    component:MainNavComponent , 
    children:[
      {
        path: '',
        component: DashComponent
        
      },
      {path: 'dashInfo/:type' , component:DashInfoComponent , resolve: { data: UserResolver}},
      {path: 'history' , component:EmployeeListComponent, resolve: { data: UserResolver}},

      {path: 'settings' , component:SettingsComponent, resolve: { data: UserResolver}},

      {path: 'datatable' , component:DataTablesAppointmentComponent, resolve: { data: UserResolver}}

    ],
    resolve: { data: UserResolver}
  },
  {path: 'user', component: UserComponent,  resolve: { data: UserResolver}},
  {path: 'passwordForm' , component:PasswordFormComponent},
  {path: 'login/resetPassword', component: ResetPasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
