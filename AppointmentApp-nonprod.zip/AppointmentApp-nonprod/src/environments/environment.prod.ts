export const environment = {
  production: true,
   firebaseConfig: {
      apiKey: "AIzaSyB1dB6GBF7mIfwp2WmR4HjPqeb1yr71Rzo",
      authDomain: "apointo-4bf65.firebaseapp.com",
      databaseURL: "https://apointo-4bf65.firebaseio.com",
      projectId: "apointo-4bf65",
      storageBucket: "apointo-4bf65.appspot.com",
      messagingSenderId: "370590346220",
      appId: "1:370590346220:web:573fe7046ecacb6d502ec9",
      measurementId: "G-EQ72G2JZV1"
     }
};
