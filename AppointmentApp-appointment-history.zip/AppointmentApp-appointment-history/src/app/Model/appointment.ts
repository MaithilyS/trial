export class Appointment{
// Comments: string;
Name : string;
Address : string;
// Service: string
TimeSlot: string;
status: string
date : string;
contact :string;

}