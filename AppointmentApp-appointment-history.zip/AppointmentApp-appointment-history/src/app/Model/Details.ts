export class Details{
    businessName: string;
    address: string;
    contact:string;
    city: string;
    state: string;
}