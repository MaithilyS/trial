export class ServiceDetails{
    ServiceName : string;
    Working_Days : string;
    AppointmentSlots : string 
} 