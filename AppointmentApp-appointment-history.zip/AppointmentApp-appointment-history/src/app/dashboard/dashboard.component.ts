import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Details } from 'src/app/Model/Details';
import { FormService } from 'src/app/shared/form.service';
import { ServiceDetails } from '../Model/ServiceDetails';
import { AuthService } from '../core/auth.service';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor( public authService: AuthService, private location : Location, private route: ActivatedRoute){

  }
  ngOnInit(){
    
  }

  logout(){
    this.authService.SignOut()
    .then((res) => {
     // this.location.back();
    }, (error) => {
      console.log("Logout error", error);
    });
  }
}
