import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Details } from 'src/app/Model/Details';
import { FormService } from 'src/app/shared/form.service';
import { ServiceDetails } from 'src/app/Model/ServiceDetails';
import { UserService } from 'src/app/core/user.service';
import { FirebaseUserModel } from 'src/app/core/user.model';
import { Router, Params } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-business-form',
  templateUrl: './business-form.component.html',
  styleUrls: ['./business-form.component.css']
})
export class BusinessFormComponent implements OnInit {
  businessForm : FormGroup
  service_details: FormGroup
  detail : Details
  serviceDetails : ServiceDetails
  formValue : boolean = true

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];


  user: FirebaseUserModel = new FirebaseUserModel();
  constructor(private formService :FormService, public userService: UserService,private route: ActivatedRoute,
    private location : Location,private router: Router) { }

  ngOnInit() {
   
    this.route.data.subscribe(routeData => {
      let data = routeData['data'];
      if (data) {
        this.user = data;
      }
    })
    this.businessForm = new FormGroup({
      businessName: new FormControl(null, Validators.required),
      businessType: new FormControl('Health', Validators.required),
      address: new FormControl(null, [Validators.email, Validators.required]),   
      contact: new FormControl(null),
      city: new FormControl('Mumbai', [Validators.required]),
      state: new FormControl('MH', [Validators.required]),
      // user_notification: new FormControl('email') 
    
});
this.createServiceForm();
  }

createServiceForm(){
  this.service_details= new FormGroup({
    ServiceName : new FormControl(null, [Validators.required]),
    Working_Days :  new FormControl('Monday', [Validators.required]),
    AppointmentSlots : new FormControl('10-12', [Validators.required]),
  });
}
  onSubmit(){
    this.formValue =false
    this.detail= new Details();
    this.detail.businessName =this.businessForm.get('businessName').value;
    this.detail.address =this.businessForm.get('address').value;
    this.detail.contact =this.businessForm.get('contact').value;
    this.detail.city =this.businessForm.get('city').value;
    this.detail.state =this.businessForm.get('state').value;
    console.log(this.detail);
    this.createServiceForm();
   
  
  }
  onFinalSubmit(){
    this.serviceDetails= new ServiceDetails();
    this.serviceDetails.ServiceName =this.service_details.get('ServiceName').value;
    this.serviceDetails.Working_Days =this.service_details.get('Working_Days').value;
    this.serviceDetails.AppointmentSlots =this.service_details.get('AppointmentSlots').value;
    this.formService.insertBusinessDetails(this.detail,this.serviceDetails,this.user.uid);
    //this.formService.insertBusinessDetails('b105',this.detail);
    this.router.navigate(['/dashboard']);
    
  }

  toggle(){
    this.formValue=true;
    // location.reload();
  }

}
