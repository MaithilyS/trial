import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../shared/employee.service';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Appointment } from '../Model/appointment';
import { ActivatedRoute } from '@angular/router';
import { FirebaseUserModel } from '../core/user.model';
import { FormService } from '../shared/form.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import { Inject } from '@angular/core';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-create-modal',
  templateUrl: './create-modal.component.html',
  styleUrls: ['./create-modal.component.css']
})

export class CreateModalComponent implements OnInit {
  form: FormGroup ;
  appModel : Appointment;
  user: FirebaseUserModel = new FirebaseUserModel();

  constructor(public service : FormService,private route: ActivatedRoute, public snackBar: MatSnackBar,@Inject(MAT_DIALOG_DATA) public data: any, private datePipe: DatePipe) { }

  ngOnInit(): void {
this.user.uid =this.data.uid;
  this.form = new FormGroup({
      Name: new FormControl('', Validators.required),
      Address: new FormControl('', Validators.required),
      contact: new FormControl('', [Validators.required, Validators.minLength(8)]),
      TimeSlot: new FormControl(0),
      date:new FormControl(''),
      status:new FormControl('')
    });
  }

 

  initializeFormGroup() {
    this.form.setValue({
      Name: '',
      Address: '',
      contact: '',
      TimeSlot: 0,
      date:'',
      status:''
    });
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
       duration: 3000,
    });
  }
  onClear() {
    this.form.reset();
    this.initializeFormGroup();
    this.openSnackBar("cleared!","done!")
  }

  onSubmit() {
    this.appModel = new Appointment();
    this.appModel.Name =this.form.get('Name').value;
    this.appModel.Address =this.form.get('Address').value;
    this.appModel.status =this.form.get('status').value;
    this.appModel.TimeSlot =this.form.get('TimeSlot').value;
    this.appModel.date =this.datePipe.transform(this.form.get('date').value, 'yyyy-MM-dd');
    this.appModel.contact =this.form.get('contact').value;
    this.service.insertAppointment(this.appModel,this.user.uid)
    this.openSnackBar("Successfully created Appointment!" , "done!")
    this.initializeFormGroup();
    // this.form.reset();
  console.log(this.appModel)
 }
}
