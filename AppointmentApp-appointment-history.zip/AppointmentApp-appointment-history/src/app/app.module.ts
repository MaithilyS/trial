import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// import { ClientHistoryComponent } from './client-history/client-history.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthService } from './core/auth.service';
import { FormService } from './shared/form.service';
import { UserComponent } from './user/user.component';
import { UserService } from './core/user.service';
import { AngularFireModule } from "@angular/fire";
import { AngularFirestoreModule } from "@angular/fire/firestore";
import { BusinessFormComponent } from './onboarding/business-form/business-form.component';
import { environment } from 'src/environments/environment';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { HistoryComponent } from './history/history.component';
import {EmployeeListComponent} from './employees/employee-list/employee-list.component';
import { UserResolver } from './user/user.resolver';
import { AuthGuard } from './core/auth.guard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReactiveFormsModule } from '@angular/forms';
import {AngularFireAuthModule} from '@angular/fire/auth';
import { FormsModule } from '@angular/forms';
import {MatNativeDateModule} from '@angular/material/core';
import { MaterialModule } from './material/material.module';
import { MainNavComponent } from './main-nav/main-nav.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { CreateModalComponent } from './create-modal/create-modal.component';
import { EmployeeService } from './shared/employee.service';
import { DatePipe } from '@angular/common';
import {MatSnackBarModule } from '@angular/material/snack-bar'
@NgModule({
  declarations: [
    AppComponent,
    BusinessFormComponent,
    DashboardComponent,
    // HistoryComponent,
    LoginComponent,
    UserComponent,
    RegisterComponent,
    // ClientHistoryComponent,
    EmployeeListComponent,
    MainNavComponent,
    AppointmentComponent,
    CreateModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AngularFirestoreModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    BrowserAnimationsModule ,
    MatSnackBarModule ,
    MaterialModule,
    MatNativeDateModule,
    FormsModule
  ],
  providers: [FormService,AuthService,UserService ,UserResolver, AuthGuard, EmployeeService,DatePipe],
  bootstrap: [AppComponent],
  entryComponents:[CreateModalComponent]
})
export class AppModule { }
