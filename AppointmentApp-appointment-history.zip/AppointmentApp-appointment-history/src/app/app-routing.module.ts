import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { HistoryComponent } from './history/history.component';
import { BusinessFormComponent } from './onboarding/business-form/business-form.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { UserResolver } from './user/user.resolver';
import { AuthGuard } from './core/auth.guard';
// import { ClientHistoryComponent } from './client-history/client-history.component';
import { EmployeeListComponent } from './employees/employee-list/employee-list.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { AppointmentComponent } from './appointment/appointment.component';

const routes: Routes = [
  {path: '', redirectTo: 'login', pathMatch: 'full' },
  {path: 'signup' , component:RegisterComponent, canActivate:[AuthGuard] },
  {path: 'login' , component:LoginComponent ,canActivate:[AuthGuard] },
  {path: 'business-form' , component:BusinessFormComponent, resolve: { data: UserResolver}},
  {
    path: 'dashboard' ,
    component:MainNavComponent , 
    children:[
      {
        path: '',
        component: AppointmentComponent
      },
      {path: 'history' , component:EmployeeListComponent, resolve: { data: UserResolver}}
    ],
    resolve: { data: UserResolver}
  },
  {path: 'user', component: UserComponent,  resolve: { data: UserResolver}}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
