import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { firestore } from 'firebase';
import { DatePipe } from '@angular/common';

export interface ClientHistoryItem {
  Name :string;
  Address:string;
  TimeSlot : string;
  contact:string;
  date :firestore.Timestamp;
}


@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  todayDate :string;
  constructor(private firestore: AngularFirestore, private datePipe: DatePipe) { }

  getAppointment(businesssId) { 
    return  this.firestore.collection("Business").doc(businesssId).collection<ClientHistoryItem>("Appointments").valueChanges();
  }
  getTodayAppointment(businesssId) { 
    var d = Date();
    this.todayDate = this.datePipe.transform(d, 'yyyy-MM-dd');
    return  this.firestore.collection("Business").doc(businesssId).collection<ClientHistoryItem>("Appointments",ref => ref.where('date', '==', this.todayDate)).valueChanges();
  }
}
