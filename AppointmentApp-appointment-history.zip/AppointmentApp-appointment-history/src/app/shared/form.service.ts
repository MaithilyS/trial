import { Injectable } from "@angular/core";
import { AngularFirestore } from "@angular/fire/firestore";
import { Details } from "../Model/Details";
import { ServiceDetails } from "../Model/ServiceDetails";
import { Appointment } from '../Model/appointment';

@Injectable({
  providedIn: "root",
})
export class FormService {
  // businessId: string
  constructor(private firestore: AngularFirestore) {}

  insertAppointment(app : Appointment, businessId){
    var businessDocument = this.firestore
    .collection("Business")
    .doc(businessId);

    businessDocument
    .collection("Appointments")
    .add(JSON.parse(JSON.stringify(app)))
    .then(function () {
      console.log("Appointment Added");
    })
    .catch(function (error) {
      console.error("Error adding  document:", error);
    });
  }

  insertBusinessDetails(details: Details, serviceDetails ,businessId) {
//this.businessId = firebase.auth.Currentuser.uid;
console.log(businessId)
    var businessDocument = this.firestore
      .collection("Business")
      .doc(businessId);
    
  
    console.log(JSON.parse(JSON.stringify(serviceDetails)));
    businessDocument
      .collection("Services")
      .add(JSON.parse(JSON.stringify(serviceDetails)))
      .then(function () {
        console.log("Services Document Added");
      })
      .catch(function (error) {
        console.error("Error adding document:", error);
      });
    //   businessDocument.collection('Appointment');

    businessDocument
      .collection("Details")
      .add(JSON.parse(JSON.stringify(details)))
      .then(function () {
        console.log(" Details Document Added");
      })
      .catch(function (error) {
        console.error("Error adding document:", error);
      });
   }
}
