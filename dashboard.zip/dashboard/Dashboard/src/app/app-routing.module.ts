import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientHistoryComponent } from './client-history/client-history.component';

import { EditDetailsComponent } from './edit-details/edit-details.component';


const routes: Routes = [
  { path: 'ClientHistory', component: ClientHistoryComponent },
  
  {path: 'EditDetails' , component: EditDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
